# Plagiarism-Detector
Second project of the Udacity Machine Learning Engineer Nanodegree program where I have created a plagiarism detector using custom similarity features amongst source and answer file such as containment and longest common subsequence further training and deploying on Amazon Sagemaker
